# bulwark-mail

Helm chart for [Bulwark Mail](https://github.com/bulwarkmail/webmail) — a self-hosted JMAP webmail.

[![ArtifactHub](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/l4g)](https://artifacthub.io/packages/search?repo=l4g)

Pinned to Bulwark **1.6.0**.
The chart deploys a stateless Bulwark Deployment behind a native Kubernetes `Ingress` with multi-host TLS support, suitable for serving multiple webmail domains from a single deployment.

## Architecture

```
                   ┌──────────────────────────────────┐
                   │        Ingress (nginx)           │
                   │   mail.example.com               │
                   │   webmail.example.com            │
                   │   tls: bulwark-tls (multi-SAN)   │
                   └──────────────┬───────────────────┘
                                  │
                   ┌──────────────▼───────────────────┐
                   │     Service: bulwark-mail        │
                   │     ClusterIP, :80 → :3000       │
                   └──────────────┬───────────────────┘
                                  │
                   ┌──────────────▼───────────────────┐
                   │   Deployment: bulwark-mail       │
                   │   replicas=N, anti-affinity      │
                   │                                  │
                   │   Pod 1   Pod 2   Pod 3          │
                   │     │       │       │            │
                   └─────┼───────┼───────┼────────────┘
                         │       │       │
                         └───────┴───────┴───▶  JMAP_SERVER_URL
                                                 (Stalwart)
```

## Quick start

```bash
helm repo add l4g https://l4gdev.github.io/helm-charts
helm install bulwark l4g/bulwark-mail \
  --set config.jmapServerUrl=https://mail.example.com
```

Or with a values file:

```bash
helm install bulwark l4g/bulwark-mail \
  -f charts/bulwark-mail/examples/values-minimal.yaml
```

## JMAP server URL

`config.jmapServerUrl` is exposed verbatim to the browser through `/api/config`. The frontend then fetches `${jmapServerUrl}/.well-known/jmap` and `${jmapServerUrl}/jmap/` directly — Bulwark does **not** server-side proxy the bulk of the JMAP traffic.

This has two practical consequences:

- The URL must be publicly resolvable. A cluster-internal Service name (`*.svc.cluster.local`) makes the browser fail with `Unable to reach the server` even though the Bulwark pod can reach it.
- If the webmail and the JMAP server are on different origins, the JMAP server must permit credentialed CORS for the webmail origin (`Access-Control-Allow-Origin: <webmail>` plus `Access-Control-Allow-Credentials: true`). Stalwart 0.16 does not emit `Allow-Credentials` on its own; either override at the ingress (see the stalwart-mail-ha chart README) or set `usePermissiveCors=false` plus custom `responseHeaders` in Stalwart's admin UI.

A same-origin layout — webmail under `https://mail.example.com/webmail/`, Stalwart at the host root — sidesteps CORS entirely. Set `NEXT_PUBLIC_BASE_PATH=/webmail` via `extraEnv` and point the ingress at that path.

## Values

### Top-level

| Key | Default | Description |
| --- | --- | --- |
| `replicaCount` | `2` | Pod replicas. Bulwark is stateless. |
| `image.repository` | `ghcr.io/bulwarkmail/webmail` | Container image. |
| `image.tag` | `""` | Defaults to `Chart.appVersion`. |
| `service.type` | `ClusterIP` | |
| `service.port` | `80` | Service port. |
| `service.targetPort` | `3000` | Container listen port (matches `config.port`). |

### Bulwark configuration

Each value under `config` maps to one upstream env var (`JMAP_SERVER_URL`, `APP_NAME`, etc.).
Empty strings are skipped, so unsetting a branding value falls back to the upstream default.

| Key | Maps to | Required |
| --- | --- | --- |
| `config.jmapServerUrl` | `JMAP_SERVER_URL` | yes |
| `config.hostname` | `HOSTNAME` | yes (default `0.0.0.0`) |
| `config.port` | `PORT` | yes (default `3000`) |
| `config.appName` | `APP_NAME` | no |
| `config.loginCompanyName` | `LOGIN_COMPANY_NAME` | no |
| `config.allowCustomJmapEndpoint` | `ALLOW_CUSTOM_JMAP_ENDPOINT` | no |
| `config.stalwartFeatures` | `STALWART_FEATURES` | no |

The full list lives in `values.yaml` under `config:`.

### OIDC

Set `oidc.enabled: true` and reference an existing Secret holding the client secret:

```yaml
oidc:
  enabled: true
  clientId: bulwark-webmail
  issuerUrl: "https://idp.example.com/application/o/bulwark/"
  existingClientSecret: bulwark-oidc
  existingClientSecretKey: client-secret
```

The chart mounts the secret at `/etc/bulwark/oauth-client-secret` and points `OAUTH_CLIENT_SECRET_FILE` at it, so the value never lands in an env var.

### Session secret

`session.existingSecret` references a Secret containing the cookie-encryption key.
If unset, the chart generates a random 64-character key on first install and stores it in `<release>-bulwark-mail-session`; subsequent upgrades preserve it via `lookup`.

### Ingress (multi-host TLS)

Group multiple hosts under one `tls[]` entry to share a SAN cert:

```yaml
ingress:
  enabled: true
  className: nginx
  hosts:
    - host: mail.example.com
      paths:
        - path: /
          pathType: Prefix
    - host: webmail.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: bulwark-tls
      hosts:
        - mail.example.com
        - webmail.example.com
```


#### Extra ingresses (admin allowlist, rate limits)

ingress-nginx annotations apply per Ingress object, so to put an IP allowlist or a rate
limit on `/admin` and `/api/admin` only, declare an additional Ingress for those paths:

```yaml
ingress:
  extra:
    - name: admin
      annotations:
        nginx.ingress.kubernetes.io/whitelist-source-range: "203.0.113.0/24"
      hosts:
        - host: mail.example.com
          paths:
            - path: /admin
              pathType: Prefix
            - path: /api/admin
              pathType: Prefix
```

Extra ingresses reuse `ingress.className` unless they set their own, render independently of
`ingress.enabled`, and can be switched off individually with `enabled: false`.

`networkPolicy.ingressFrom` accepts a list of NetworkPolicyPeer entries and, when set, replaces
the namespace-wide default so only e.g. the ingress-controller pods may reach the webmail port.
### Settings sync

By default Bulwark stores per-user settings server-side under `/app/data`.
The chart mounts it as `emptyDir` (per-pod, lost on restart).
For persistent settings, drop to a single replica and enable PVC:

```yaml
replicaCount: 1
settingsSync:
  enabled: true
  persistence:
    enabled: true
    size: 5Gi
```

### Optional resources

Each gated behind `<resource>.enabled`:

- `metrics.serviceMonitor` — Prometheus scrape on `/metrics`.
- `networkPolicy` — namespace-level ingress; egress to DNS and `jmapEgressPorts` only.
- `podDisruptionBudget`, `autoscaling`.

## Security

- Runs as non-root user 1000, read-only root filesystem, all capabilities dropped.
- Session secret and OIDC client secret are file-mounted, never env-injected.
- `automountServiceAccountToken: false`.

## Upgrading

`helm upgrade` is sufficient for any 1.x → 1.y bump within Bulwark.
This chart targets Bulwark 1.6.0; on rollback to a chart version pinning an older Bulwark, the new image features (subpath deployment, image attachment thumbnails, mobile-friendly admin) revert automatically.
